WPD.dom._fn.plugin("ajaxsearchlite",window.WPD.ajaxsearchlite.plugin);
